#include <GL/glut.h>

void inicializacao(void) {
   glClearColor(0.0, 0.0, 0.0, 0.0);
   glMatrixMode(GL_PROJECTION);
   gluOrtho2D(-2.0, 2.0, -2.0, 2.0); // Ajustou a proje��o ortogr�fica
}

void desenhaBonecoPalito(void) {
   // Cabe�a (quadrado)
   glColor3f(1.0, 0.0, 0.0);
   glBegin(GL_QUADS);
       glVertex2f(-0.2, 0.2);
       glVertex2f(-0.2, 0.4);
       glVertex2f(0.2, 0.4);
       glVertex2f(0.2, 0.2);
   glEnd();

   // Corpo (linha)
   glColor3f(0.0, 1.0, 0.0);
   glBegin(GL_LINES);
       glVertex2f(0.0, 0.2);
       glVertex2f(0.0, -0.4);
   glEnd();

   // Perna esquerda (linha)
   glColor3f(0.0, 0.0, 1.0);
   glBegin(GL_LINES);
       glVertex2f(0.0, -0.4);
       glVertex2f(-0.2, -0.6);
   glEnd();

   // Perna direita (linha)
   glBegin(GL_LINES);
       glVertex2f(0.0, -0.4);
       glVertex2f(0.2, -0.6);
   glEnd();

   // Bra�o esquerdo (linha)
   glColor3f(1.0, 1.0, 0.0);
   glBegin(GL_LINES);
       glVertex2f(0.0, 0.0);
       glVertex2f(-0.2, 0.1);
   glEnd();

   // Bra�o direito (linha)
   glBegin(GL_LINES);
       glVertex2f(0.0, 0.0);
       glVertex2f(0.2, 0.1);
   glEnd();
}

void exibicao(void) {
   glClear(GL_COLOR_BUFFER_BIT);
   glLoadIdentity();
   desenhaBonecoPalito();
   glFlush();
}

int main(int argc, char** argv) {
   glutInit(&argc, argv);
   glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
   glutInitWindowSize(500, 500);
   glutInitWindowPosition(100, 100);
   glutCreateWindow("Boneco Palito");
   inicializacao();
   glutDisplayFunc(exibicao);
   glutMainLoop();

   return 0;
}
