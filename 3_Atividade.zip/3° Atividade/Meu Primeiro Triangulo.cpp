#include <stdio.h>
#include <GL/glut.h>

void inicializacao(void);
void desenha(void);

float posicoes[] = {
    -0.5, -0.5,
     0.5, -0.5,
     0.0, 0.5
};

float cores[] = {
    1.0, 0.0, 0.0,
    0.0, 1.0, 0.0,
    0.0, 0.0, 1.0
};

int main(int argc, char** argv){
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DEPTH | GLUT_SINGLE | GLUT_RGBA);
    glutInitWindowPosition(100, 100);
    glutInitWindowSize(640, 480);
    glutCreateWindow("Meu Primeiro Tri�ngulo");

    inicializacao();

    glutDisplayFunc(desenha);

    glutMainLoop();
}

void inicializacao(){
    glClearColor(0, 0, 0, 0);
}

void desenha(void){
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    glEnableClientState(GL_VERTEX_ARRAY);
    glEnableClientState(GL_COLOR_ARRAY);

    glVertexPointer(2, GL_FLOAT, 2 * sizeof(float), posicoes);
    glColorPointer(3, GL_FLOAT, 3 * sizeof(float), cores);

    glDrawArrays(GL_TRIANGLES, 0, 3);

    glDisableClientState(GL_VERTEX_ARRAY);
    glFlush();
}
